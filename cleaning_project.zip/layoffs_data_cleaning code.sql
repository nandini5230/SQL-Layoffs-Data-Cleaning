SELECT*FROM
layoffs;
-- steps for data cleaning:
-- 1. remove duplicates
-- 2. standardize the data ( issues in data like spelling mistakes)
-- 3. null values or blank values
-- 4. remove any cloumns
-- create  another table same as layoffs
CREATE TABLE layoffs_staging
LIKE layoffs;

SELECT*
FROM layoffs_staging;


-- insert all cloumns  like raw table i.e layoffs
INSERT layoffs_staging
SELECT*
FROM layoffs;
-- 1. remove duplicates
-- 1.1 now konw the duplicates

with duplicate_cte AS
(
SELECT*,ROW_NUMBER() OVER(
PARTITION BY company,location,industry,total_laid_off,percentage_laid_off,'date',stage,country,funds_raised_millions)
AS row_num
FROM layoffs_staging
)
SELECT*
FROM duplicate_cte
where row_num>1;



-- duplicate cte of the delete is not updateable
-- you can't update cte of the delete statement as like update statement. 
-- so we create another table that has extra rows and then deleting it where row=2.
-- creating another table by right click
CREATE TABLE `layoffs_staging2` (
  `company` text,
  `location` text,
  `industry` text,
  `total_laid_off` int DEFAULT NULL,
  `percentage_laid_off` text,
  `date` text,
  `stage` text,
  `country` text,
  `funds_raised_millions` int ,
   `row_num` INT
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
select* from layoffs_staging2;
-- empty table is created so insert values
INSERT INTO layoffs_staging2
SELECT*,ROW_NUMBER() OVER(
PARTITION BY company,location,industry,total_laid_off,percentage_laid_off,'date',stage,country,funds_raised_millions)
AS row_num
FROM layoffs_staging;
-- now the row_num at as a perment cloumn
-- now delete the  rows where row_num>1
DELETE FROM layoffs_staging2
WHERE row_num > 1;


-- set SQL_SAFE_UPDATES = 0; used for when delete iw not working then qurey  off safety after that turn back on

-- standardizing data
--  remove spacing in the begining in company column
SELECT company,TRIM(company)
FROM layoffs_staging2;

-- cant update and delete these things u need to go to edit-preference-sql editior-go down unselect-save it
 
 UPDATE layoffs_staging2
 SET company = TRIM(company);

-- issue in industries are same kind of industries are in diff records

SELECT* FROM layoffs_staging2
WHERE industry LIKE 'crypto%';

UPDATE layoffs_staging2
SET industry = 'crypto'
WHERE industry LIKE 'crypto%';
-- now cloumn of location
select distinct location
from layoffs_staging2
order by location;
-- there is no issue
-- now cloumn of country
select distinct country
from layoffs_staging2
order by country;
-- there is a issue i.e( united states.)
update layoffs_staging2
set country = trim(trailing '.'from country)
where country like 'united states%';

-- now column of date
alter table layoffs_staging2
add  date_new DATE;
update layoffs_staging2
set date_new= str_to_date(`date`,'%mm%dd%yyyy');
describe layoffs_staging2;
show columns from layoffs_staging2;
update layoffs_staging2
set date_new = str_to_date(`date`,'%m%d%y')
where `date` regexp '^[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}';

update layoffs_staging2
set `date` = trim(`date`);
select `date`,date_new
from layoffs_staging2
limit 10;
 
 select distinct`date`
 from layoffs_staging2
 limit 20;
 update layoffs_staging2
 set `date` = replace(`date` ,'-','/');
update layoffs_staging2
set date_new =str_to_date(`date`,'%m/%d%y')
where `date` like '%/%/%';
UPDATE layoffs_staging2
SET date_new =
CASE
  WHEN STR_TO_DATE(`date`, '%m/%d/%Y') IS NOT NULL
       THEN STR_TO_DATE(`date`, '%m/%d/%Y')
  WHEN STR_TO_DATE(`date`, '%Y-%m-%d') IS NOT NULL
       THEN STR_TO_DATE(`date`, '%Y-%m-%d')
  ELSE NULL
END;

SELECT `date`, date_new
FROM layoffs_staging2
LIMIT 10;

SELECT `date`
FROM layoffs_staging2
WHERE date_new IS NULL;

ALTER TABLE layoffs_staging2 DROP COLUMN `date`;
ALTER TABLE layoffs_staging2 CHANGE date_new `date` DATE;

-- null and blank values
select* 
from layoffs_staging2
where total_laid_off is null and percentage_laid_off is null;
 update layoffs_staging2
 set industry =null
 where industry='';
 select* from layoffs_staging2
 where industry=null or industry='';
 
 select* from layoffs_staging2
 where company = 'Airbnb';
 
 select t1.industry,t2.industry
 from layoffs_staging2 t1
 join layoffs_staging2 t2
  on t1.company = t2.company
  where (t1.industry is null or t1.industry ='')
  and t2.industry is not null;
  

 update layoffs_staging2 t1
 join layoffs_staging2 t2
  on t1.company = t2.company
  set t1.industry=t2.industry
  where (t1.industry is null or t1.industry ='')
  and t2.industry is not null;
  
  -- removing unnecessary cloumns or rows
  delete
  from layoffs_staging2
  where total_laid_off is null
  and percentage_laid_off is null;
  
  select*from layoffs_staging2;
   -- remove columns
   alter table layoffs_staging2
   drop column row_num;
  
  